import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  icon: LucideIcon;
  label: string;
  value: string | number;
  change?: { value: number; isPositive: boolean };
}

export function StatCard({ icon: Icon, label, value, change }: StatCardProps) {
  return (
    <div className="bg-stone-700 rounded-lg p-6 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-stone-400 text-sm font-medium">{label}</span>
        <div className="bg-orange-500 bg-opacity-20 p-2 rounded-lg">
          <Icon size={20} className="text-orange-500" />
        </div>
      </div>
      <div className="text-white text-2xl font-bold">{value}</div>
      {change && (
        <div className={`text-xs font-medium ${change.isPositive ? 'text-green-400' : 'text-red-400'}`}>
          {change.isPositive ? '↑' : '↓'} {Math.abs(change.value)}%
        </div>
      )}
    </div>
  );
}

interface ActionButtonProps {
  icon: LucideIcon;
  label: string;
  variant?: 'primary' | 'secondary' | 'danger';
  onClick?: () => void;
}

export function ActionButton({ icon: Icon, label, variant = 'primary', onClick }: ActionButtonProps) {
  const variants = {
    primary: 'bg-orange-500 hover:bg-orange-600 text-white',
    secondary: 'bg-stone-600 hover:bg-stone-700 text-stone-100',
    danger: 'bg-red-600 hover:bg-red-700 text-white',
  };

  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${variants[variant]}`}
    >
      <Icon size={18} />
      {label}
    </button>
  );
}

interface SectionHeaderProps {
  title: string;
  icon?: LucideIcon;
  actionLabel?: string;
  onAction?: () => void;
}

export function SectionHeader({ title, icon: Icon, actionLabel, onAction }: SectionHeaderProps) {
  return (
    <div className="flex items-center justify-between mb-6">
      <div className="flex items-center gap-3">
        {Icon && <Icon size={24} className="text-orange-500" />}
        <h2 className="text-white text-xl font-bold">{title}</h2>
      </div>
      {actionLabel && (
        <button
          onClick={onAction}
          className="text-orange-500 hover:text-orange-400 text-sm font-medium transition-colors"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}

interface StatusBadgeProps {
  status: 'pending' | 'preparing' | 'ready' | 'served' | 'completed' | 'active';
  label?: string;
  count?: number;
}

export function StatusBadge({ status, label, count }: StatusBadgeProps) {
  const statusStyles = {
    pending: 'bg-stone-600 text-stone-100',
    preparing: 'bg-orange-600 text-orange-100',
    ready: 'bg-green-600 text-green-100',
    served: 'bg-blue-600 text-blue-100',
    completed: 'bg-stone-600 text-stone-100',
    active: 'bg-yellow-600 text-yellow-100',
  };

  return (
    <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium ${statusStyles[status]}`}>
      {label || status}
      {count !== undefined && <span className="font-bold">{count}</span>}
    </span>
  );
}

interface TabsProps {
  tabs: Array<{ label: string; value: string }>;
  activeTab: string;
  onChange: (value: string) => void;
}

export function Tabs({ tabs, activeTab, onChange }: TabsProps) {
  return (
    <div className="flex gap-2 border-b border-stone-600">
      {tabs.map(tab => (
        <button
          key={tab.value}
          onClick={() => onChange(tab.value)}
          className={`px-4 py-2 font-medium transition-colors border-b-2 ${
            activeTab === tab.value
              ? 'text-orange-500 border-orange-500'
              : 'text-stone-400 border-transparent hover:text-stone-300'
          }`}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
}
