import { LucideIcon } from 'lucide-react';

interface SidebarItemProps {
  icon: LucideIcon;
  label: string;
  isActive: boolean;
  onClick: () => void;
}

function SidebarItem({ icon: Icon, label, isActive, onClick }: SidebarItemProps) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors font-medium ${
        isActive
          ? 'bg-orange-500 text-white'
          : 'text-stone-300 hover:bg-stone-700 hover:text-white'
      }`}
    >
      <Icon size={20} />
      <span>{label}</span>
    </button>
  );
}

interface SidebarProps {
  items: Array<{ label: string; icon: LucideIcon; value: string }>;
  activeItem: string;
  onItemClick: (value: string) => void;
  onLogout: () => void;
  userName: string;
}

export function Sidebar({ items, activeItem, onItemClick, onLogout, userName }: SidebarProps) {
  return (
    <div className="hidden md:flex w-64 bg-stone-800 flex-col gap-6 p-6 h-screen fixed left-0 top-0">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center font-bold text-white">
          D
        </div>
        <div>
          <div className="text-white font-bold">DINEFLOW</div>
        </div>
      </div>

      <div className="flex-1 flex flex-col gap-2">
        {items.map(item => (
          <SidebarItem
            key={item.value}
            icon={item.icon}
            label={item.label}
            isActive={activeItem === item.value}
            onClick={() => onItemClick(item.value)}
          />
        ))}
      </div>

      <div className="pt-4 border-t border-stone-700">
        <div className="mb-4">
          <p className="text-stone-400 text-xs uppercase font-bold">Current User</p>
          <p className="text-white font-medium text-sm mt-1">{userName}</p>
        </div>
        <button
          onClick={onLogout}
          className="w-full px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-medium transition-colors"
        >
          Logout
        </button>
      </div>
    </div>
  );
}

interface MobileSidebarProps {
  items: Array<{ label: string; icon: LucideIcon; value: string }>;
  activeItem: string;
  onItemClick: (value: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export function MobileSidebar({ items, activeItem, onItemClick, isOpen, onClose }: MobileSidebarProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-40 md:hidden">
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose} />
      <div className="absolute left-0 top-0 h-screen w-64 bg-stone-800 p-6 z-50">
        {items.map(item => (
          <SidebarItem
            key={item.value}
            icon={item.icon}
            label={item.label}
            isActive={activeItem === item.value}
            onClick={() => {
              onItemClick(item.value);
              onClose();
            }}
          />
        ))}
      </div>
    </div>
  );
}
