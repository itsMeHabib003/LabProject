import { Bell, User, Menu } from 'lucide-react';

interface HeaderProps {
  title: string;
  userName: string;
  onMenuClick?: () => void;
  notificationCount?: number;
}

export function Header({ title, userName, onMenuClick, notificationCount }: HeaderProps) {
  return (
    <div className="bg-stone-900 border-b border-stone-700 px-6 py-4">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          {onMenuClick && (
            <button onClick={onMenuClick} className="md:hidden p-2 hover:bg-stone-800 rounded-lg">
              <Menu size={20} className="text-stone-300" />
            </button>
          )}
          <div>
            <p className="text-orange-500 text-sm font-medium">Dashboard</p>
            <p className="text-white text-lg font-bold">{title}</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative">
            <button className="relative p-2 hover:bg-stone-800 rounded-lg">
              <Bell size={20} className="text-stone-400" />
              {notificationCount && notificationCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-orange-500 rounded-full text-xs text-white flex items-center justify-center font-bold">
                  {notificationCount}
                </span>
              )}
            </button>
          </div>

          <div className="h-10 w-10 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center text-white font-bold cursor-pointer hover:opacity-80 transition-opacity">
            <span className="text-sm">{userName.charAt(0)}</span>
          </div>

          <div className="hidden md:block">
            <p className="text-white font-medium text-sm">{userName}</p>
            <p className="text-stone-400 text-xs">Admin</p>
          </div>
        </div>
      </div>
    </div>
  );
}
