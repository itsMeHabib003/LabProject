import { createContext, useContext, useState, ReactNode } from 'react';
import { Order, OrderItem, MenuItem } from '../types';

interface OrderContextType {
  orders: Order[];
  currentOrder: Order | null;
  createOrder: (tableNumber: number) => void;
  addItemToOrder: (menuItem: MenuItem, quantity: number) => void;
  removeItemFromOrder: (itemId: string) => void;
  placeOrder: () => void;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  getOrderById: (orderId: string) => Order | undefined;
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

export function OrderProvider({ children }: { children: ReactNode }) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);

  const createOrder = (tableNumber: number) => {
    const newOrder: Order = {
      id: `ORD-${Date.now()}`,
      orderNumber: String(Math.floor(Math.random() * 10000)).padStart(4, '0'),
      tableNumber,
      items: [],
      status: 'pending',
      totalAmount: 0,
      createdAt: new Date(),
    };
    setCurrentOrder(newOrder);
  };

  const addItemToOrder = (menuItem: MenuItem, quantity: number) => {
    if (!currentOrder) return;
    const existingItem = currentOrder.items.find(item => item.menuItem.id === menuItem.id);
    const updatedItems = existingItem
      ? currentOrder.items.map(item =>
          item.menuItem.id === menuItem.id ? { ...item, quantity: item.quantity + quantity } : item
        )
      : [...currentOrder.items, { id: `${menuItem.id}-${Date.now()}`, menuItem, quantity }];

    const totalAmount = updatedItems.reduce((sum, item) => sum + item.menuItem.price * item.quantity, 0);
    setCurrentOrder({ ...currentOrder, items: updatedItems, totalAmount });
  };

  const removeItemFromOrder = (itemId: string) => {
    if (!currentOrder) return;
    const updatedItems = currentOrder.items.filter(item => item.id !== itemId);
    const totalAmount = updatedItems.reduce((sum, item) => sum + item.menuItem.price * item.quantity, 0);
    setCurrentOrder({ ...currentOrder, items: updatedItems, totalAmount });
  };

  const placeOrder = () => {
    if (!currentOrder || currentOrder.items.length === 0) return;
    const placedOrder: Order = {
      ...currentOrder,
      status: 'preparing',
      createdAt: new Date(),
    };
    setOrders([...orders, placedOrder]);
    setCurrentOrder(null);
  };

  const updateOrderStatus = (orderId: string, status: Order['status']) => {
    setOrders(
      orders.map(order => (order.id === orderId ? { ...order, status } : order))
    );
  };

  const getOrderById = (orderId: string) => {
    return orders.find(order => order.id === orderId);
  };

  return (
    <OrderContext.Provider
      value={{
        orders,
        currentOrder,
        createOrder,
        addItemToOrder,
        removeItemFromOrder,
        placeOrder,
        updateOrderStatus,
        getOrderById,
      }}
    >
      {children}
    </OrderContext.Provider>
  );
}

export function useOrders() {
  const context = useContext(OrderContext);
  if (!context) {
    throw new Error('useOrders must be used within OrderProvider');
  }
  return context;
}
