export type UserRole = 'staff' | 'kitchen' | 'admin';

export interface User {
  id: string;
  name: string;
  username: string;
  role: UserRole;
  shift?: string;
}

export interface MenuItem {
  id: string;
  name: string;
  price: number;
  category: string;
}

export type OrderStatus = 'pending' | 'preparing' | 'ready' | 'served' | 'completed';

export interface OrderItem {
  id: string;
  menuItem: MenuItem;
  quantity: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  tableNumber: number;
  items: OrderItem[];
  status: OrderStatus;
  totalAmount: number;
  createdAt: Date;
  prepTime?: number;
}

export interface StaffMetrics {
  totalOrders: number;
  activeOrders: number;
  completedOrders: number;
  totalRevenue: number;
}
