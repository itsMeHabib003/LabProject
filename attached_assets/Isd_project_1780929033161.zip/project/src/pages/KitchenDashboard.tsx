import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { KITCHEN_ORDERS, MOCK_ORDERS } from '../data/mockData';
import { Header } from '../components/layout/Header';
import { Sidebar, MobileSidebar } from '../components/layout/Sidebar';
import { SectionHeader, StatusBadge, Tabs } from '../components/common/index';
import { ChefHat, Bell, Clock, CheckCircle, AlertCircle, User, BarChart3, FileText, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function KitchenDashboard() {
  const { user, logout: authLogout } = useAuth();
  const navigate = useNavigate();
  const [activePage, setActivePage] = useState('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'pending' | 'cooking' | 'ready'>('pending');

  const handleLogout = () => {
    authLogout();
    navigate('/login');
  };

  const sidebarItems = [
    { label: 'Dashboard', icon: BarChart3, value: 'dashboard' },
    { label: 'Queue', icon: ChefHat, value: 'queue' },
    { label: 'Analytics', icon: FileText, value: 'analytics' },
    { label: 'Profile', icon: User, value: 'profile' },
  ];

  const ordersByStatus = {
    pending: MOCK_ORDERS.filter(o => o.status === 'pending'),
    cooking: MOCK_ORDERS.filter(o => o.status === 'preparing'),
    ready: MOCK_ORDERS.filter(o => o.status === 'ready'),
  };

  return (
    <div className="flex h-screen bg-stone-900">
      <Sidebar
        items={sidebarItems}
        activeItem={activePage}
        onItemClick={setActivePage}
        onLogout={handleLogout}
        userName={user?.name || 'Kitchen'}
      />
      <MobileSidebar
        items={sidebarItems}
        activeItem={activePage}
        onItemClick={setActivePage}
        isOpen={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
      />

      <div className="flex-1 md:ml-64 flex flex-col overflow-hidden">
        <Header
          title={user?.name || 'Kitchen Dashboard'}
          userName={user?.name || 'Kitchen'}
          onMenuClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          notificationCount={2}
        />

        <div className="flex-1 overflow-y-auto">
          <div className="p-6 space-y-6">
            {activePage === 'dashboard' && (
              <>
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h1 className="text-white text-2xl font-bold">Manage Incoming Orders</h1>
                    <p className="text-stone-400">Manage incoming orders and cooking queue in real time</p>
                  </div>
                  <div className="bg-yellow-600 text-yellow-100 px-4 py-2 rounded-full font-bold flex items-center gap-2">
                    <AlertCircle size={18} />
                    12 Active Orders
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 space-y-6">
                    <div className="bg-stone-800 rounded-lg p-6">
                      <div className="flex items-center justify-between mb-6">
                        <div>
                          <h2 className="text-white font-bold text-lg flex items-center gap-2">
                            <Bell size={20} className="text-orange-500" />
                            Incoming Orders
                          </h2>
                          <p className="text-stone-400 text-sm">2 new</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {KITCHEN_ORDERS.map(order => (
                          <div key={order.id} className="bg-stone-700 rounded-lg p-4 border border-stone-600">
                            <div className="flex items-center justify-between mb-3">
                              <div>
                                <div className="text-white font-bold">#{order.id}</div>
                                <div className="text-stone-400 text-sm">Table {order.table}</div>
                              </div>
                              <div className="flex items-center gap-1 text-orange-400 bg-orange-500 bg-opacity-20 px-2 py-1 rounded">
                                <Clock size={14} />
                                <span className="text-xs font-bold">{order.time} min</span>
                              </div>
                            </div>
                            <div className="space-y-1 mb-4">
                              {order.items.map((item, idx) => (
                                <div key={idx} className="text-stone-300 text-sm flex items-center gap-2">
                                  <ChefHat size={14} className="text-orange-500" />
                                  {item}
                                </div>
                              ))}
                            </div>
                            <div className="flex gap-2">
                              <button className="flex-1 px-3 py-2 bg-green-600 hover:bg-green-700 text-white text-sm rounded-lg font-medium transition-colors flex items-center justify-center gap-1">
                                <CheckCircle size={16} />
                                Accept
                              </button>
                              <button className="flex-1 px-3 py-2 bg-red-600 hover:bg-red-700 text-white text-sm rounded-lg font-medium transition-colors">
                                Reject
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="bg-stone-800 rounded-lg p-6">
                      <SectionHeader title="Active Cooking Queue" />
                      <Tabs
                        tabs={[
                          { label: `Pending (${ordersByStatus.pending.length})`, value: 'pending' },
                          { label: `Cooking (${ordersByStatus.cooking.length})`, value: 'cooking' },
                          { label: `Ready (${ordersByStatus.ready.length})`, value: 'ready' },
                        ]}
                        activeTab={activeTab}
                        onChange={v => setActiveTab(v as typeof activeTab)}
                      />

                      <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {ordersByStatus[activeTab].map(order => (
                          <div
                            key={order.id}
                            className={`rounded-lg p-4 border-2 ${
                              activeTab === 'pending'
                                ? 'border-stone-600 bg-stone-700'
                                : activeTab === 'cooking'
                                  ? 'border-orange-600 bg-orange-500 bg-opacity-10'
                                  : 'border-green-600 bg-green-500 bg-opacity-10'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-3">
                              <div className="text-white font-bold">#{order.orderNumber}</div>
                              <StatusBadge status={activeTab === 'cooking' ? 'preparing' : activeTab as 'pending' | 'ready'} />
                            </div>
                            <div className="text-stone-400 text-sm mb-3">
                              Table {order.tableNumber} • {order.items.length} items
                            </div>
                            <div className="space-y-1 mb-4">
                              {order.items.map(item => (
                                <div key={item.id} className="text-stone-300 text-sm">
                                  • {item.menuItem.name} × {item.quantity}
                                </div>
                              ))}
                            </div>
                            {activeTab === 'pending' && (
                              <button className="w-full px-3 py-2 bg-orange-500 hover:bg-orange-600 text-white text-sm rounded-lg font-medium transition-colors">
                                Start Cooking
                              </button>
                            )}
                            {activeTab === 'cooking' && (
                              <button className="w-full px-3 py-2 bg-green-600 hover:bg-green-700 text-white text-sm rounded-lg font-medium transition-colors">
                                Mark Ready
                              </button>
                            )}
                            {activeTab === 'ready' && (
                              <div className="text-center text-green-400 text-sm font-bold py-2">
                                Ready for Pickup
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="bg-stone-800 rounded-lg p-6">
                      <h3 className="text-white font-bold mb-4 flex items-center gap-2">
                        <Bell size={20} className="text-orange-500" />
                        Notifications
                      </h3>
                      <div className="space-y-3">
                        <div className="bg-green-500 bg-opacity-20 border border-green-600 rounded-lg p-3">
                          <div className="text-green-400 text-sm font-medium">Table 3 order ready for pickup</div>
                          <div className="text-green-300 text-xs mt-1">2 mins ago</div>
                        </div>
                        <div className="bg-orange-500 bg-opacity-20 border border-orange-600 rounded-lg p-3">
                          <div className="text-orange-400 text-sm font-medium">New order from Table 9</div>
                          <div className="text-orange-300 text-xs mt-1">5 mins ago</div>
                        </div>
                        <div className="bg-blue-500 bg-opacity-20 border border-blue-600 rounded-lg p-3">
                          <div className="text-blue-400 text-sm font-medium">Waiter requested update on Table 5</div>
                          <div className="text-blue-300 text-xs mt-1">8 mins ago</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}

            {activePage === 'queue' && (
              <div className="bg-stone-800 rounded-lg p-6">
                <SectionHeader title="Complete Cooking Queue" />
                <div className="text-stone-400 text-center py-12">
                  Queue view with full order details
                </div>
              </div>
            )}

            {activePage === 'analytics' && (
              <div className="bg-stone-800 rounded-lg p-6">
                <SectionHeader title="Kitchen Analytics" />
                <div className="text-stone-400 text-center py-12">
                  Average cooking time, order fulfillment metrics
                </div>
              </div>
            )}

            {activePage === 'profile' && (
              <div className="bg-stone-800 rounded-lg p-6 max-w-md">
                <SectionHeader title="Profile" icon={User} />
                <div className="space-y-4">
                  <div>
                    <label className="block text-stone-400 text-sm mb-1">Name</label>
                    <div className="text-white font-medium">{user?.name}</div>
                  </div>
                  <div>
                    <label className="block text-stone-400 text-sm mb-1">Role</label>
                    <div className="text-white font-medium capitalize">{user?.role}</div>
                  </div>
                  <div>
                    <label className="block text-stone-400 text-sm mb-1">Status</label>
                    <div className="text-green-400 font-medium">Active</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
