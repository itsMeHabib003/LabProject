import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { ADMIN_STATS } from '../data/mockData';
import { Header } from '../components/layout/Header';
import { Sidebar, MobileSidebar } from '../components/layout/Sidebar';
import { StatCard, SectionHeader, StatusBadge } from '../components/common/index';
import { BarChart3, Users, Menu, TrendingUp, AlertTriangle, Edit, Trash2, Plus, User, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function AdminDashboard() {
  const { user, logout: authLogout } = useAuth();
  const navigate = useNavigate();
  const [activePage, setActivePage] = useState('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    authLogout();
    navigate('/login');
  };

  const sidebarItems = [
    { label: 'Dashboard', icon: BarChart3, value: 'dashboard' },
    { label: 'Orders', icon: Menu, value: 'orders' },
    { label: 'Bills', icon: TrendingUp, value: 'bills' },
    { label: 'Profile', icon: User, value: 'profile' },
  ];

  return (
    <div className="flex h-screen bg-stone-900">
      <Sidebar
        items={sidebarItems}
        activeItem={activePage}
        onItemClick={setActivePage}
        onLogout={handleLogout}
        userName={user?.name || 'Admin'}
      />
      <MobileSidebar
        items={sidebarItems}
        activeItem={activePage}
        onItemClick={setActivePage}
        isOpen={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
      />

      <div className="flex-1 md:ml-64 flex flex-col overflow-hidden">
        <Header
          title="Admin Panel"
          userName={user?.name || 'Admin'}
          onMenuClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        />

        <div className="flex-1 overflow-y-auto">
          <div className="p-6 space-y-6">
            {activePage === 'dashboard' && (
              <>
                <div>
                  <h1 className="text-white text-3xl font-bold">Admin Dashboard</h1>
                  <p className="text-stone-400">Overview of The Grand Bistro performance today</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <StatCard
                    icon={TrendingUp}
                    label="Today's Revenue"
                    value={`₹${ADMIN_STATS.dailyRevenue.toLocaleString()}`}
                    change={{ value: ADMIN_STATS.revenueChange, isPositive: true }}
                  />
                  <StatCard
                    icon={Menu}
                    label="Orders"
                    value={ADMIN_STATS.totalOrders}
                  />
                  <StatCard
                    icon={Users}
                    label="Active Staff"
                    value={`${ADMIN_STATS.activeStaff} on shift now`}
                  />
                  <StatCard
                    icon={AlertTriangle}
                    label="Stock"
                    value={`${ADMIN_STATS.stockLevel}%`}
                  />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-stone-800 rounded-lg p-6">
                    <SectionHeader title="Menu Management" icon={Menu} />
                    <div className="space-y-3">
                      <div className="flex items-center justify-between bg-stone-700 p-4 rounded-lg">
                        <div>
                          <div className="text-white font-medium">Margherita Pizza</div>
                          <div className="text-stone-400 text-sm">Pizza • ₹450</div>
                        </div>
                        <div className="flex gap-2">
                          <button className="p-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition-colors">
                            <Edit size={16} />
                          </button>
                          <button className="p-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors">
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                      <div className="flex items-center justify-between bg-stone-700 p-4 rounded-lg">
                        <div>
                          <div className="text-white font-medium">Grilled Salmon</div>
                          <div className="text-stone-400 text-sm">Main • ₹650</div>
                        </div>
                        <div className="flex gap-2">
                          <button className="p-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition-colors">
                            <Edit size={16} />
                          </button>
                          <button className="p-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors">
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                    </div>
                    <button className="w-full mt-4 flex items-center justify-center gap-2 px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg font-medium transition-colors">
                      <Plus size={18} />
                      Add Menu Item
                    </button>
                  </div>

                  <div className="bg-stone-800 rounded-lg p-6">
                    <SectionHeader title="Staff Management" icon={Users} />
                    <div className="space-y-3">
                      <div className="flex items-center justify-between bg-stone-700 p-4 rounded-lg">
                        <div>
                          <div className="text-white font-medium">Sarah</div>
                          <div className="text-stone-400 text-sm">Waiter • Morning Shift</div>
                        </div>
                        <div className="flex gap-2">
                          <button className="p-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition-colors">
                            <Edit size={16} />
                          </button>
                          <button className="p-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors">
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                      <div className="flex items-center justify-between bg-stone-700 p-4 rounded-lg">
                        <div>
                          <div className="text-white font-medium">Marco Rossi</div>
                          <div className="text-stone-400 text-sm">Kitchen • Day Shift</div>
                        </div>
                        <div className="flex gap-2">
                          <button className="p-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition-colors">
                            <Edit size={16} />
                          </button>
                          <button className="p-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors">
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                    </div>
                    <button className="w-full mt-4 flex items-center justify-center gap-2 px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg font-medium transition-colors">
                      <Plus size={18} />
                      Add Staff Member
                    </button>
                  </div>

                  <div className="bg-stone-800 rounded-lg p-6">
                    <SectionHeader title="Order Management" icon={Menu} />
                    <div className="flex gap-3">
                      <div className="flex-1">
                        <div className="text-stone-400 text-xs mb-1">Completed</div>
                        <StatusBadge status="ready" label="Completed" count={98} />
                      </div>
                      <div className="flex-1">
                        <div className="text-stone-400 text-xs mb-1">Pending</div>
                        <StatusBadge status="pending" label="Pending" count={24} />
                      </div>
                      <div className="flex-1">
                        <div className="text-stone-400 text-xs mb-1">Active</div>
                        <StatusBadge status="active" label="Active" count={12} />
                      </div>
                    </div>
                    <button className="w-full mt-4 px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg font-medium transition-colors">
                      View All Orders
                    </button>
                  </div>

                  <div className="bg-stone-800 rounded-lg p-6">
                    <SectionHeader title="Inventory" icon={AlertTriangle} />
                    <div className="space-y-3">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-stone-300">Tomatoes</span>
                          <span className="text-orange-400 text-sm">18%</span>
                        </div>
                        <div className="w-full bg-stone-700 rounded-full h-2">
                          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '18%' }} />
                        </div>
                      </div>
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-stone-300">Cheese</span>
                          <span className="text-orange-400 text-sm">64%</span>
                        </div>
                        <div className="w-full bg-stone-700 rounded-full h-2">
                          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '64%' }} />
                        </div>
                      </div>
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-stone-300">Flour</span>
                          <span className="text-orange-400 text-sm">88%</span>
                        </div>
                        <div className="w-full bg-stone-700 rounded-full h-2">
                          <div className="bg-orange-500 h-2 rounded-full" style={{ width: '88%' }} />
                        </div>
                      </div>
                    </div>
                    <button className="w-full mt-4 px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg font-medium transition-colors">
                      Restock
                    </button>
                  </div>
                </div>

                <div className="bg-stone-800 rounded-lg p-6">
                  <SectionHeader title="Analytics" icon={BarChart3} />
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <h4 className="text-stone-400 text-sm mb-4 font-medium">Daily Revenue</h4>
                      <div className="flex items-end justify-between gap-1 h-32">
                        {[65, 45, 78, 56, 89, 72, 85].map((height, i) => (
                          <div key={i} className="flex-1 bg-orange-500 rounded-t" style={{ height: `${height}%` }} />
                        ))}
                      </div>
                    </div>
                    <div>
                      <h4 className="text-stone-400 text-sm mb-4 font-medium">Popular Menu Items</h4>
                      <div className="space-y-2">
                        {[
                          { name: 'Pizza', count: 320 },
                          { name: 'Pasta', count: 245 },
                          { name: 'Burger', count: 180 },
                        ].map(item => (
                          <div key={item.name} className="flex items-center justify-between">
                            <span className="text-stone-300 text-sm">{item.name}</span>
                            <div className="flex items-center gap-2">
                              <div className="w-24 bg-stone-700 rounded-full h-1">
                                <div
                                  className="bg-orange-500 h-1 rounded-full"
                                  style={{ width: `${(item.count / 320) * 100}%` }}
                                />
                              </div>
                              <span className="text-orange-400 text-xs font-bold w-8">{item.count}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h4 className="text-stone-400 text-sm mb-4 font-medium">Weekly Orders</h4>
                      <div className="space-y-2">
                        {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, i) => (
                          <div key={day} className="flex items-center gap-2">
                            <span className="text-stone-400 text-xs w-8">{day}</span>
                            <div className="w-full bg-stone-700 rounded-full h-1">
                              <div
                                className="bg-orange-500 h-1 rounded-full"
                                style={{ width: `${30 + i * 15}%` }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-yellow-900 bg-opacity-30 border border-yellow-700 rounded-lg p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-yellow-600 rounded-full flex items-center justify-center">
                      <AlertTriangle size={20} className="text-yellow-100" />
                    </div>
                    <div>
                      <p className="text-yellow-100 font-medium">Low Stock Alert</p>
                      <p className="text-yellow-200 text-sm">Tomatoes Running Low</p>
                    </div>
                  </div>
                  <button className="px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg font-medium transition-colors">
                    Restock
                  </button>
                </div>
              </>
            )}

            {activePage === 'orders' && (
              <div className="bg-stone-800 rounded-lg p-6">
                <SectionHeader title="Order Management" />
                <div className="text-stone-400 text-center py-12">
                  Detailed view of all orders with filtering and sorting options
                </div>
              </div>
            )}

            {activePage === 'bills' && (
              <div className="bg-stone-800 rounded-lg p-6">
                <SectionHeader title="Billing & Revenue" />
                <div className="text-stone-400 text-center py-12">
                  Revenue analytics and billing history
                </div>
              </div>
            )}

            {activePage === 'profile' && (
              <div className="bg-stone-800 rounded-lg p-6 max-w-md">
                <SectionHeader title="Profile" icon={User} />
                <div className="space-y-4">
                  <div>
                    <label className="block text-stone-400 text-sm mb-1">Restaurant Name</label>
                    <div className="text-white font-medium">{user?.name}</div>
                  </div>
                  <div>
                    <label className="block text-stone-400 text-sm mb-1">Role</label>
                    <div className="text-white font-medium capitalize">{user?.role}</div>
                  </div>
                  <div>
                    <label className="block text-stone-400 text-sm mb-1">Status</label>
                    <div className="text-green-400 font-medium">Active</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
