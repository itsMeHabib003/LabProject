import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Eye, EyeOff, Flame, ChefHat, Lock, Users } from 'lucide-react';

export function LoginPage() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!username || !password) {
      setError('Please enter both username and password');
      return;
    }

    const result = login(username, password);
    if (result.success) {
      const userRole = username === 'staff' ? 'staff' : username === 'kitchen' ? 'kitchen' : 'admin';
      const dashboardRoutes: Record<string, string> = {
        staff: '/staff',
        kitchen: '/kitchen',
        admin: '/admin',
      };
      navigate(dashboardRoutes[userRole]);
    } else {
      setError(result.error || 'Login failed');
    }
  };

  const roles = [
    { username: 'staff', label: 'Staff (Waiter)', icon: <Users size={20} /> },
    { username: 'kitchen', label: 'Kitchen', icon: <ChefHat size={20} /> },
    { username: 'admin', label: 'Admin', icon: <Lock size={20} /> },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-900 via-stone-800 to-orange-900 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-orange-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-orange-700 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse" />
      </div>

      <div className="relative z-10 min-h-screen flex items-center justify-between px-4 sm:px-6 lg:px-8">
        <div className="hidden lg:flex flex-col justify-center max-w-lg">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-12 bg-orange-500 rounded-lg flex items-center justify-center">
              <Flame className="text-white" size={28} />
            </div>
            <div>
              <div className="text-white font-bold text-2xl">DINEFLOW</div>
              <div className="text-orange-400 text-sm">Smart Restaurant Management</div>
            </div>
          </div>

          <h1 className="text-white text-5xl font-bold mb-6 leading-tight">
            Welcome to DineFlow
          </h1>
          <p className="text-stone-300 text-lg mb-8 leading-relaxed">
            Manage orders, kitchen workflows, and billing in one elegant place. Sign in to continue to your dashboard.
          </p>

          <div className="flex gap-4">
            <div className="w-12 h-12 bg-orange-500 bg-opacity-20 rounded-lg flex items-center justify-center">
              <Flame size={24} className="text-orange-400" />
            </div>
            <div className="w-12 h-12 bg-orange-500 bg-opacity-20 rounded-lg flex items-center justify-center">
              <ChefHat size={24} className="text-orange-400" />
            </div>
            <div className="w-12 h-12 bg-orange-500 bg-opacity-20 rounded-lg flex items-center justify-center">
              <Lock size={24} className="text-orange-400" />
            </div>
          </div>
        </div>

        <div className="w-full max-w-md">
          <div className="bg-stone-800 bg-opacity-80 backdrop-blur-sm border border-stone-700 rounded-2xl p-8 shadow-2xl">
            <h2 className="text-white text-2xl font-bold mb-2">Sign In</h2>
            <p className="text-stone-400 text-sm mb-8">
              Enter your credentials to access your account
            </p>

            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <label className="block text-stone-300 text-sm font-medium mb-3">
                  Username
                </label>
                <div className="relative">
                  <Users
                    size={18}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-orange-500"
                  />
                  <input
                    type="text"
                    value={username}
                    onChange={e => setUsername(e.target.value)}
                    placeholder="Enter your username"
                    className="w-full bg-stone-700 border border-stone-600 rounded-lg pl-10 pr-4 py-3 text-white placeholder-stone-500 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-stone-300 text-sm font-medium mb-3">
                  Password
                </label>
                <div className="relative">
                  <Lock
                    size={18}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-orange-500"
                  />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full bg-stone-700 border border-stone-600 rounded-lg pl-10 pr-10 py-3 text-white placeholder-stone-500 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-300"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="bg-red-500 bg-opacity-20 border border-red-600 rounded-lg p-3 flex items-center gap-2">
                  <div className="flex-shrink-0">
                    <Lock size={18} className="text-red-400" />
                  </div>
                  <p className="text-red-300 text-sm">{error}</p>
                </div>
              )}

              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="remember"
                  className="w-4 h-4 rounded border-stone-600 bg-stone-700 accent-orange-500 cursor-pointer"
                />
                <label htmlFor="remember" className="ml-2 text-stone-400 text-sm cursor-pointer">
                  Remember Me
                </label>
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-bold py-3 rounded-lg transition-all duration-200 transform hover:scale-105 flex items-center justify-center gap-2"
              >
                <Lock size={18} />
                Login
              </button>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-stone-600" />
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-stone-800 text-stone-400">or select role</span>
                </div>
              </div>

              <div className="space-y-2">
                {roles.map(role => (
                  <button
                    key={role.username}
                    type="button"
                    onClick={() => {
                      const passwords: Record<string, string> = {
                        staff: 'staff345',
                        kitchen: 'kitchen345',
                        admin: 'admin345',
                      };
                      setUsername(role.username);
                      setPassword(passwords[role.username]);
                      setError('');
                    }}
                    className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors bg-stone-700 text-stone-300 hover:bg-stone-600"
                  >
                    {role.icon}
                    {role.label}
                  </button>
                ))}
              </div>
            </form>

            <div className="mt-6 pt-6 border-t border-stone-700">
              <p className="text-stone-400 text-xs text-center mb-3">
                Demo Credentials
              </p>
              <div className="space-y-1 text-xs text-stone-500 text-center">
                <div>Staff: staff / staff345</div>
                <div>Kitchen: kitchen / kitchen345</div>
                <div>Admin: admin / admin345</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
