import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useOrders } from '../context/OrderContext';
import { MOCK_MENU_ITEMS, MOCK_ORDERS } from '../data/mockData';
import { Header } from '../components/layout/Header';
import { Sidebar, MobileSidebar } from '../components/layout/Sidebar';
import { StatCard, SectionHeader, StatusBadge, Tabs } from '../components/common/index';
import { UtensilsCrossed, FileText, BarChart3, User, Plus, X, ShoppingCart, Printer, Minus, IndianRupee } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function StaffDashboard() {
  const { user, logout: authLogout } = useAuth();
  const navigate = useNavigate();
  const { orders, currentOrder, createOrder, addItemToOrder, removeItemFromOrder, placeOrder, updateOrderStatus } = useOrders();
  const [activePage, setActivePage] = useState('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedTable, setSelectedTable] = useState<number | null>(null);
  const [showCreateOrder, setShowCreateOrder] = useState(false);
  const [activeTab, setActiveTab] = useState<'pending' | 'preparing' | 'ready' | 'served'>('pending');
  const [itemQuantities, setItemQuantities] = useState<Record<string, number>>({});
  const [billOrderId, setBillOrderId] = useState<string | null>(null);
  const [showBillPreview, setShowBillPreview] = useState(false);

  const handleLogout = () => {
    authLogout();
    navigate('/login');
  };

  const sidebarItems = [
    { label: 'Dashboard', icon: BarChart3, value: 'dashboard' },
    { label: 'Orders', icon: UtensilsCrossed, value: 'orders' },
    { label: 'Bills', icon: FileText, value: 'bills' },
    { label: 'Profile', icon: User, value: 'profile' },
  ];

  const tables = Array.from({ length: 12 }, (_, i) => {
    const number = i + 1;
    const tableOrder = orders.find(o => o.tableNumber === number);
    return {
      number,
      status: tableOrder ? 'occupied' : ['available', 'reserved'][Math.floor(Math.random() * 2)] as 'available' | 'occupied' | 'reserved',
    };
  });

  const tablesStatus = {
    available: tables.filter(t => t.status === 'available').length,
    occupied: tables.filter(t => t.status === 'occupied').length,
    reserved: tables.filter(t => t.status === 'reserved').length,
  };

  const allOrders = [...orders, ...MOCK_ORDERS];
  const ordersStatus = {
    pending: allOrders.filter(o => o.status === 'pending').length,
    preparing: allOrders.filter(o => o.status === 'preparing').length,
    ready: allOrders.filter(o => o.status === 'ready').length,
    served: allOrders.filter(o => o.status === 'served').length,
  };

  const handleCreateOrder = (tableNumber: number) => {
    createOrder(tableNumber);
    setSelectedTable(tableNumber);
    setItemQuantities({});
    setShowCreateOrder(true);
  };

  const handleAddItem = (menuItemId: string) => {
    const quantity = itemQuantities[menuItemId] || 1;
    const menuItem = MOCK_MENU_ITEMS.find(m => m.id === menuItemId);
    if (menuItem) {
      addItemToOrder(menuItem, quantity);
      setItemQuantities({ ...itemQuantities, [menuItemId]: 0 });
    }
  };

  const handleQuantityChange = (menuItemId: string, quantity: number) => {
    setItemQuantities({ ...itemQuantities, [menuItemId]: Math.max(0, quantity) });
  };

  const handlePlaceOrder = () => {
    if (currentOrder && currentOrder.items.length > 0) {
      placeOrder();
      setShowCreateOrder(false);
      setSelectedTable(null);
      setItemQuantities({});
    }
  };

  const handleGenerateBill = (orderId: string) => {
    setBillOrderId(orderId);
    setShowBillPreview(true);
  };

  const handlePrintBill = () => {
    window.print();
  };

  const getBillOrder = () => {
    if (!billOrderId) return null;
    return allOrders.find(o => o.id === billOrderId);
  };

  const completedOrders = allOrders.filter(o => o.status === 'served');

  return (
    <div className="flex h-screen bg-stone-900">
      <Sidebar
        items={sidebarItems}
        activeItem={activePage}
        onItemClick={setActivePage}
        onLogout={handleLogout}
        userName={user?.name || 'Staff'}
      />
      <MobileSidebar
        items={sidebarItems}
        activeItem={activePage}
        onItemClick={setActivePage}
        isOpen={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
      />

      <div className="flex-1 md:ml-64 flex flex-col overflow-hidden">
        <Header
          title={user?.name || 'Staff Dashboard'}
          userName={user?.name || 'Staff'}
          onMenuClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          notificationCount={ordersStatus.ready}
        />

        <div className="flex-1 overflow-y-auto">
          <div className="p-6 space-y-6">
            {activePage === 'dashboard' && (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <StatCard
                    icon={UtensilsCrossed}
                    label="Available Tables"
                    value={tablesStatus.available}
                  />
                  <StatCard
                    icon={ShoppingCart}
                    label="Active Orders"
                    value={ordersStatus.pending + ordersStatus.preparing}
                  />
                  <StatCard
                    icon={UtensilsCrossed}
                    label="Ready to Serve"
                    value={ordersStatus.ready}
                  />
                  <StatCard
                    icon={FileText}
                    label="Total Today"
                    value="₹2,450"
                  />
                </div>

                <div className="bg-stone-800 rounded-lg p-6">
                  <SectionHeader title="Available Tables" />
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                    {tables.map(table => (
                      <button
                        key={table.number}
                        onClick={() => table.status === 'available' && handleCreateOrder(table.number)}
                        disabled={table.status !== 'available'}
                        className={`aspect-square rounded-lg font-bold text-sm transition-colors flex items-center justify-center ${
                          table.status === 'available'
                            ? 'bg-green-600 hover:bg-green-700 text-white cursor-pointer'
                            : table.status === 'occupied'
                              ? 'bg-red-600 text-white cursor-not-allowed'
                              : 'bg-yellow-600 text-white cursor-not-allowed'
                        }`}
                      >
                        T{table.number}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="bg-stone-800 rounded-lg p-6">
                  <SectionHeader title="Recent Orders" actionLabel="View all" />
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {allOrders.slice(0, 3).map(order => (
                      <div key={order.id} className="bg-stone-700 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="text-white font-bold">#{order.orderNumber}</div>
                          <StatusBadge status={order.status} />
                        </div>
                        <div className="text-stone-400 text-sm mb-2">
                          Table {order.tableNumber} • {order.items.length} items
                        </div>
                        <div className="text-orange-400 font-bold mb-3">₹{order.totalAmount}</div>
                        {order.status === 'ready' && (
                          <button className="w-full px-3 py-2 bg-green-600 hover:bg-green-700 text-white text-sm rounded-lg font-medium transition-colors">
                            Mark Served
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            {activePage === 'orders' && (
              <div className="bg-stone-800 rounded-lg p-6">
                <SectionHeader title="Order Management" />
                <Tabs
                  tabs={[
                    { label: `Pending (${ordersStatus.pending})`, value: 'pending' },
                    { label: `Preparing (${ordersStatus.preparing})`, value: 'preparing' },
                    { label: `Ready (${ordersStatus.ready})`, value: 'ready' },
                    { label: `Served (${ordersStatus.served})`, value: 'served' },
                  ]}
                  activeTab={activeTab}
                  onChange={v => setActiveTab(v as typeof activeTab)}
                />
                <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                  {allOrders.filter(o => o.status === activeTab).map(order => (
                    <div key={order.id} className="bg-stone-700 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <div className="text-white font-bold">#{order.orderNumber}</div>
                          <div className="text-stone-400 text-sm">Table {order.tableNumber}</div>
                        </div>
                        <StatusBadge status={order.status} />
                      </div>
                      <div className="space-y-2 mb-4">
                        {order.items.map(item => (
                          <div key={item.id} className="text-stone-300 text-sm">
                            {item.menuItem.name} × {item.quantity} - ₹{item.menuItem.price * item.quantity}
                          </div>
                        ))}
                      </div>
                      <div className="flex items-center justify-between pt-4 border-t border-stone-600">
                        <span className="text-orange-400 font-bold">₹{order.totalAmount}</span>
                        {activeTab === 'ready' && (
                          <button
                            onClick={() => updateOrderStatus(order.id, 'served')}
                            className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white text-sm rounded-lg transition-colors"
                          >
                            Serve
                          </button>
                        )}
                        {activeTab === 'served' && (
                          <button
                            onClick={() => handleGenerateBill(order.id)}
                            className="px-3 py-1 bg-orange-500 hover:bg-orange-600 text-white text-sm rounded-lg transition-colors flex items-center gap-1"
                          >
                            <FileText size={14} />
                            Bill
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                  {allOrders.filter(o => o.status === activeTab).length === 0 && (
                    <div className="col-span-2 text-center py-12 text-stone-400">
                      No orders in {activeTab} status
                    </div>
                  )}
                </div>
              </div>
            )}

            {activePage === 'bills' && (
              <div className="bg-stone-800 rounded-lg p-6">
                <SectionHeader title="Generate Bills" />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {completedOrders.map(order => (
                    <div key={order.id} className="bg-stone-700 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <div className="text-white font-bold">Order #{order.orderNumber}</div>
                          <div className="text-stone-400 text-sm">Table {order.tableNumber}</div>
                        </div>
                        <StatusBadge status="completed" label="Completed" />
                      </div>
                      <div className="space-y-1 mb-4 text-stone-300 text-sm">
                        {order.items.slice(0, 2).map(item => (
                          <div key={item.id}>
                            {item.menuItem.name} × {item.quantity}
                          </div>
                        ))}
                        {order.items.length > 2 && (
                          <div className="text-stone-400 text-xs">+{order.items.length - 2} more items</div>
                        )}
                      </div>
                      <div className="flex items-center justify-between pt-4 border-t border-stone-600">
                        <div className="text-orange-400 font-bold">₹{order.totalAmount}</div>
                        <button
                          onClick={() => handleGenerateBill(order.id)}
                          className="px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg font-medium transition-colors flex items-center gap-2"
                        >
                          <FileText size={16} />
                          Generate Bill
                        </button>
                      </div>
                    </div>
                  ))}
                  {completedOrders.length === 0 && (
                    <div className="col-span-2 text-center py-12 text-stone-400">
                      No completed orders to bill yet
                    </div>
                  )}
                </div>
              </div>
            )}

            {activePage === 'profile' && (
              <div className="bg-stone-800 rounded-lg p-6 max-w-md">
                <SectionHeader title="Profile" icon={User} />
                <div className="space-y-4">
                  <div>
                    <label className="block text-stone-400 text-sm mb-1">Name</label>
                    <div className="text-white font-medium">{user?.name}</div>
                  </div>
                  <div>
                    <label className="block text-stone-400 text-sm mb-1">Username</label>
                    <div className="text-white font-medium">{user?.username}</div>
                  </div>
                  <div>
                    <label className="block text-stone-400 text-sm mb-1">Role</label>
                    <div className="text-white font-medium capitalize">{user?.role}</div>
                  </div>
                  <div>
                    <label className="block text-stone-400 text-sm mb-1">Current Shift</label>
                    <div className="text-white font-medium">{user?.shift}</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {showCreateOrder && currentOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4">
          <div className="bg-stone-800 rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-stone-900 border-b border-stone-700 px-6 py-4 flex items-center justify-between">
              <div>
                <h3 className="text-white font-bold text-lg">Create Order - Table {selectedTable}</h3>
                <p className="text-stone-400 text-sm">Add items to order</p>
              </div>
              <button
                onClick={() => setShowCreateOrder(false)}
                className="p-2 hover:bg-stone-700 rounded-lg text-stone-400 hover:text-white"
              >
                <X size={20} />
              </button>
            </div>

            <div className="p-6 space-y-3">
              {MOCK_MENU_ITEMS.map(item => (
                <div key={item.id} className="bg-stone-700 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="text-white font-medium">{item.name}</div>
                      <div className="text-stone-400 text-sm">{item.category}</div>
                      <div className="text-orange-400 font-bold">₹{item.price}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleQuantityChange(item.id, (itemQuantities[item.id] || 0) - 1)}
                        className="p-1 bg-stone-600 hover:bg-stone-500 text-white rounded"
                      >
                        <Minus size={14} />
                      </button>
                      <input
                        type="number"
                        min="0"
                        value={itemQuantities[item.id] || 0}
                        onChange={e => handleQuantityChange(item.id, parseInt(e.target.value) || 0)}
                        className="w-12 text-center bg-stone-600 text-white border border-stone-500 rounded py-1"
                      />
                      <button
                        onClick={() => handleQuantityChange(item.id, (itemQuantities[item.id] || 0) + 1)}
                        className="p-1 bg-stone-600 hover:bg-stone-500 text-white rounded"
                      >
                        <Plus size={14} />
                      </button>
                      <button
                        onClick={() => (itemQuantities[item.id] || 0) > 0 && handleAddItem(item.id)}
                        disabled={(itemQuantities[item.id] || 0) === 0}
                        className="px-3 py-1 bg-orange-500 hover:bg-orange-600 text-white text-sm rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed ml-2"
                      >
                        Add
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t border-stone-700 bg-stone-900 p-6">
              <div className="mb-4 bg-stone-800 rounded-lg p-4">
                <h4 className="text-white font-bold mb-3">Order Summary</h4>
                {currentOrder.items.length > 0 ? (
                  <>
                    <div className="space-y-2 mb-4">
                      {currentOrder.items.map(item => (
                        <div key={item.id} className="flex items-center justify-between text-stone-300">
                          <div>
                            {item.menuItem.name} × {item.quantity}
                          </div>
                          <div className="flex items-center gap-2">
                            <span>₹{item.menuItem.price * item.quantity}</span>
                            <button
                              onClick={() => removeItemFromOrder(item.id)}
                              className="p-1 hover:bg-red-600 text-red-400 rounded transition-colors"
                            >
                              <X size={14} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="border-t border-stone-700 pt-3 flex items-center justify-between">
                      <span className="text-white font-bold">Total:</span>
                      <span className="text-orange-400 text-xl font-bold">₹{currentOrder.totalAmount}</span>
                    </div>
                  </>
                ) : (
                  <p className="text-stone-400 text-sm">No items added yet</p>
                )}
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowCreateOrder(false)}
                  className="flex-1 px-4 py-2 bg-stone-700 hover:bg-stone-600 text-white rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handlePlaceOrder}
                  disabled={!currentOrder.items.length}
                  className="flex-1 px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Place Order (₹{currentOrder.totalAmount})
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showBillPreview && getBillOrder() && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4">
          <div className="bg-white rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className="bg-gradient-to-r from-orange-600 to-orange-700 p-6 text-white print:hidden">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold">DineFlow</h2>
                  <p className="text-orange-100 text-sm">The Grand Bistro</p>
                </div>
                <button
                  onClick={() => setShowBillPreview(false)}
                  className="p-2 hover:bg-orange-600 rounded-lg"
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            <div className="p-6 space-y-4">
              {(() => {
                const order = getBillOrder();
                if (!order) return null;
                return (
                  <>
                    <div className="border-b border-gray-300 pb-4">
                      <p className="text-gray-600 text-sm">Order Number</p>
                      <p className="text-2xl font-bold text-gray-900">#{order.orderNumber}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm border-b border-gray-300 pb-4">
                      <div>
                        <p className="text-gray-600">Table Number</p>
                        <p className="font-bold text-gray-900">{order.tableNumber}</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Date & Time</p>
                        <p className="font-bold text-gray-900">{new Date().toLocaleDateString()}</p>
                      </div>
                    </div>

                    <div className="border-b border-gray-300 pb-4">
                      <p className="text-gray-900 font-bold mb-3 uppercase text-xs">Items</p>
                      <div className="space-y-2">
                        {order.items.map(item => (
                          <div key={item.id} className="flex items-center justify-between text-sm">
                            <div>
                              <p className="text-gray-900 font-medium">{item.menuItem.name}</p>
                              <p className="text-gray-600 text-xs">₹{item.menuItem.price} x {item.quantity}</p>
                            </div>
                            <p className="text-gray-900 font-bold">₹{item.menuItem.price * item.quantity}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2 border-b border-gray-300 pb-4">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Subtotal</span>
                        <span className="text-gray-900">₹{order.totalAmount}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Tax (5%)</span>
                        <span className="text-gray-900">₹{Math.round(order.totalAmount * 0.05)}</span>
                      </div>
                    </div>

                    <div className="bg-gradient-to-r from-orange-50 to-orange-100 p-4 rounded-lg">
                      <p className="text-gray-600 text-sm mb-1">Total Amount</p>
                      <p className="text-3xl font-bold text-orange-600">
                        ₹{order.totalAmount + Math.round(order.totalAmount * 0.05)}
                      </p>
                    </div>

                    <div className="border-t border-gray-300 pt-4 text-center">
                      <p className="text-gray-600 text-xs mb-2">Thank you for dining with us!</p>
                      <p className="text-gray-500 text-xs">Please come again</p>
                    </div>
                  </>
                );
              })()}
            </div>

            <div className="flex gap-3 p-6 bg-gray-50 border-t border-gray-300 print:hidden">
              <button
                onClick={() => setShowBillPreview(false)}
                className="flex-1 px-4 py-2 bg-gray-300 hover:bg-gray-400 text-gray-900 rounded-lg font-medium transition-colors"
              >
                Close
              </button>
              <button
                onClick={handlePrintBill}
                className="flex-1 px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
              >
                <Printer size={18} />
                Print Bill
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
